<div id="book_return_div">
 	<div class="menu_header" ><div style="height:30px; width:auto; font-weight:bold; padding:4px 10px 0 10px; border-radius:5px; color:#FFF; font:1.4em; float:left; ">Return Book/s</div><div class="close" onclick="javascript:toggleSlideBox('book_return_div');">X</div></div>
    <div style="height:480px;  width:720px; margin:0 auto;  ">
     <div id="book_entry_div_control" style="height:360px; width:600px;  margin:10px;">
     <div id="mem_srh" style="margin:0 auto;height:350px; width:430px; ">
<input type="text" id="mem_search_input" name="mem_search_input"  style="border:1px solid #999; height:35px; width:422px;" class="input_text" placeholder="Enter member details: ID, Name, Email, Phone"/> 
<div id="getDetails" style="height:265px; width:434px; border-radius:6px; padding-top:40px; background:#EFEFEF; border:1px solid #FFF;">
<div  id="show_search_details" style="height:300px; width:426px;  margin-left:4px;"></div>
</div><div id="tick_error_show" style="float:right; display:none; margin:-40px -180px 10px 10px; height:20px; width:auto; padding:8px; background:#090; color:#FFF; font-weight:bold; border-radius:4px;">Return Successful</div>
<div style="height:120px; width:700px;">
<div id="member_action_for_return" style="height:150px; width:800px; display:none; background:#EFEFEF; border:1px solid #FFF; border-radius:4px; margin:10px 0 0 -130px; " >
<div style="height:90%; width:305px;  margin:10px;  float:left; ">
<div><span id="mem_name_return" style="font-size:16px; font-weight:bold; color:#161616; ">
</span>&nbsp;&nbsp;&nbsp;&nbsp;<span id="program_return" style="font-size:12px; color:#3E3E3E; "></span></div>
<div id="mem_email_return" style="font-size:13px; font-weight:700; color:#383838;"></div>
<div id="mem_u_id_return" style="font-size:13px; font-weight:700; color:#383838;"></div>
<div id="return_fine" style="font-size:13px; display:none;   font-weight:700; color:#FF0000; margin-top:15px;">
</div>
<div id="old_fine_return" style="height:20px; width:120px; color:#F00; font-weight:600; font-size:12px; margin-top:40px;"></div>
</div>
<div id="second_portion" style="height:100%; border-left:1px #999999 dotted; width:470px;  float:right; ">
<input type="text" id="retrive_and_show"  hidden="hidden"/>
<input type="text" id="hide_fine" name="hide_fine" hidden="hidden" />
<form  name="retrive_show"  method="post" style="height:120px; width:370px;">
<div style="height:100px; width:468px; "  id="book_return_select">
	
</div>
<div style="margin:15px -90px 5px 0; float:right;">
<input type="submit" name="submit" hidden="hidden" id="rt_btn" value="Return" onclick="return tick_submit();" style="height:30px; width:70px; 
background:#E2E3DD; border:1px solid #333; border-radius:4px;" />
</div>
</form>
<div id="show_book_details" ></div>
</div>
</div><!--End of member_action_for_return div from here--->
</div>
</div>
</div>
</div>
</div><!--End of book_return_div from here-->