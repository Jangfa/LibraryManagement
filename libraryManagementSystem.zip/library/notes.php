  <?PHP
  include 'Connections/connect_to_db.php';
  if(isset($_POST['pass']) != "")
  {

		$pass = "";
		$pass = $_POST['pass'];
		$check_pass = mysqli_query($connect_db,"SELECT * FROM note_details") or die("Could not connect to database");
		$data = mysqli_fetch_array($check_pass);
		$password = $data['password'];
		if($pass != $password)
		{
			echo "Password doesn't match !!! Try again";
			
		}
		else
		{
		  session_start();
		  header("Location:notes_admin.php");	
		   $_SESSION['password'] = "Userlogin";
		}
	}

  else
  {
	echo "fail";  
  }
  
  ?>