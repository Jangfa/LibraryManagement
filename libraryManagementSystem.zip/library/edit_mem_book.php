<div id="bs_remove_div" style="height:510px;">
  <div class="menu_header"><div style="height:30px; width:auto; font-weight:bold; padding:4px 10px 0 10px; border-radius:5px; color:#FFF; font:1.4em; float:left; ">Edit Book / Student Details</div>
  <div class="close" onclick="javascript:toggleSlideBox('bs_remove_div');">X</div><div style="border:1px solid #0C3; margin-top:2px; border-radius:4px; background:#6C3; height:90%; width:470px; float:right; margin-right:120px;" >
<div style="float:left; margin:3px;"><form name="e_form" method="post"><select name="choose_for_what" style="height:30px; width:80px; border-radius:4px; font-size:14px;">
<option value="book">Book</option>
<option value="member">Member</option></select></div>
<div><input type="text" id="srch_content"  style="width:376px; height:26px; margin:2px; background:#F5F5F5; border:1px solid #FFF; border-radius:4px;" placeholder="Search and select"/> </div>
  </div> </div></form>
  <div id="show_search_result" ></div>
<div id="show_for_edit" onclick="void_search();" >       
<form id="book_edit"  method='post' name="book_edit" style="padding:20px;"  >
<div style="float:right; font-size:10px; color:#999; margin:20px 50px;">
<b style="font-size:16px; color:#000;">*</b> required fields</div>
<div class="row2" style="border-radius:5px 5px 0 0;  margin-top:15px; "><div class="hello"><div class="first">Book's Unique ID:</div><div class="second" id='book_edit_id'  style="color:#6C0; background:#22C10B; color:#FFF; width:auto; height:25px; 
padding:5px 10px 0 18px; border-radius:6px;">
</div> <input type="text" id="edit_book_id" maxlength="100"   name="edit_book_id" hidden="hidden" /></div></div>
<div class="row1" ><div class="hello"><div class="first" >Book Name: *</div><div class="second" style="margin-top:5px;"><input type='text' id='book_edit_name' name="book_edit_name" maxlength="100" placeholder="Enter Book Name" style="height:26px; margin-top:-10px; z-index:-1;
width:260px; border:1px #ABB0F8 solid; border-radius:4px; "/><span id="edit_error_name" class="error_show"></span>
</div></div></div>
 <div class="row2"><div class="hello"><div class="first">Author Name*:</div><div class="second" > <input type="text"
id="book_edit_author" maxlength="100"   name="book_edit_author" placeholder="Book writer" style="height:26px; margin-top:-30px; width:260px; border:1px #ABB0F8 solid; border-radius:4px;" /><span id="edit_error_author" class="error_show"></span>  </div></div></div>
<div class="row1"><div class="hlw"><div class="first">Language: *</div><div class="second"> <select name="book_edit_lang" id="book_edit_lang" style="height:25px;    -moz-border-radius: 3px;
    -webkit-border-radius: 3px;
    -khtml-border-radius: 3px;
    border-radius: 3px;">
                <option value="language">Select book language</option>
                <option value="Nepali">Nepali</option>
                 <option value="English">English</option>
</select><span id="edit_error_language" class="error_show"></span></div></div></div>
<div class="row2"><div class="hello"><div class="first">Book Price*:</div><div class="second" > <input type="text"
  name="book_edit_price" id="book_edit_price" placeholder="In NRP"  style="height:26px; margin-top:-10px; padding-bottom:-10px; width:60px; border:1px #ABB0F8 solid; border-radius:4px;" /><span id="edit_error_price" class="error_show"></span> </div></div></div>
                
<div class="row1"><div class="hello"><div class="first">ISBN Number: </div>
<div class="second"><input type='text' name='book_edit_isbn' id='book_edit_isbn'  maxlength="80" placeholder="Book's ISBN Number" style="height:26px; margin-top:-10px; width:250px; border:1px #ABB0F8 solid; border-radius:4px;"/>
</div>
</div></div>

<div class="row2"><div class="hello"><div class="first">Edition: </div><div class="second">
<select name="book_edit_edition" style="height:25px;    -moz-border-radius: 3px; 
    -webkit-border-radius: 3px;
    -khtml-border-radius: 3px;
    border-radius: 3px;">
	<option value="Unknow">Unknow</option>
    <option value="1st">1st</option>
    <option value="2nd">2nd</option>
    <option value="3rd">3rd</option>
	<option value="4th">4th</option>
    <option value="5th">5th</option>
    <option value="6th">6th</option>
    <option value="Revised">Revised</option>
</select>
</div></div></div>
<div class="row1" style="border-radius: 0 0 5px 5px; height:60px;"><div class="hlw"><div class="first"></div><div class="second"><input type="submit"  name="book_edit_update" value="Update" onclick="return validateEditBookForm();" style="height:35px; width:90px; border:1px #666666 solid; background:#F2F2F2; border-radius:5px;" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit"  name="delete_book" value="Delete Book" hidden="hidden" style="height:35px; width:90px; border:1px #666666 solid; background:#F2F2F2; border-radius:5px;" />
</div></div></div>
</form>
<form id="edit_mem_details" method='post' name="edit_mem_details" enctype="multipart/form-data" style="padding-bottom:20px;">
<div style="float:right; font-size:10px; color:#999; margin-right:50px;"><b style="font-size:16px; color:#000;">*</b> required fields</div>
<div class="row2" style="border-radius:5px 5px 0 0;  margin-top:15px;"><div class="hello"><div class="first">Member's Unique ID: </div><div class="second" style="color:#6C0; background:#22C10B; color:#FFF; width:auto; height:25px; 
padding:5px 10px 0 18px; border-radius:6px;">
<div id="edit_mem_id"></div><input type="text" name="edit_member_unique_id" id="edit_member_unique_id" hidden="hidden" />
</div></div></div>
<div class="row1" ><div class="hello"><div class="first" >Member's Fullname: *</div><div class="second" style="margin-top:5px;"><input type='text' id='edit_fname' name="edit_fname"  maxlength="13" placeholder="First" style="height:26px; margin-top:-10px; width:110px; border:1px #ABB0F8 solid; border-radius:4px;"/>
<input type="text" name="edit_mname" id="edit_mname" maxlength="10"  placeholder="Middle" style="height:26px; margin-top:-10px; 
width:90px; border:1px #ABB0F8 solid; border-radius:4px;"/>
<input type="text" name="edit_lname" id="edit_lname" placeholder="Last" maxlength="13" style="height:26px; margin-top:-10px; width:110px; border:1px #ABB0F8 solid; border-radius:4px;"/></div></div></div>
<div class="row2" style="">
	<div class="hello" style=" width:100%;">
    <div class="first" >Member's Faculty: *</div>
    <div class="second" style="margin-top:5px; width:250px;">
        <select style="height:25px;    -moz-border-radius: 3px;
            -webkit-border-radius: 3px;
            -khtml-border-radius: 3px;
            border-radius: 3px;" name="edit_mem_faculty" id="edit_mem_faculty" >
        <option value="faculty">Select Faculty</option>
        <option value="Management">Management</option>
        <option value="Science">Science</option>
        <option value="Not Mentioned">Other</option>
        </select>
        <span class="error_show" id="edit_error_faculty" ></span>
</div>
Member's Program: *&nbsp;&nbsp;<select style="height:25px;    -moz-border-radius: 3px;
        -webkit-border-radius: 3px;
        -khtml-border-radius: 3px;
        border-radius: 3px;" name="edit_mem_program" id="edit_mem_program"  >
    <option value="program">Select Program</option>
    <option value="BCIS">BCIS</option>
    <option value="BHCM">BHCM</option>
    <option value="BBA">BBA</option>
    <option value="BPH">BPH</option>
    <option value="BSc.Nursing">BSc.Nursing</option>
    <option value="Not Mentioned">Other</option>
    </select>
    <span class="error_show" id="edit_error_program" ></span>
</div>
</div>
<div class="row1" style="">
	<div class="hello" style=" width:100%;">
    <div class="first" >Member's Semester: *</div>
    <div class="second" style="margin-top:5px; width:250px;">
                       <select style="height:25px;    -moz-border-radius: 3px;
                    -webkit-border-radius: 3px;
                    -khtml-border-radius: 3px;
                    border-radius: 3px;" name="edit_mem_semester" id="edit_mem_semester" >
                <option value="semester">Select Semester</option>
                <option value="i">First</option>
                <option value="ii">Second</option>
                <option value="iii">Third</option>
                <option value="iv">Fourth</option>
                <option value="v">Fifth</option>
                <option value="vi">Sixth</option>
                <option value="vii">Seventh</option>
                <option value="vii">Eighth</option>
                </select>
                <span class="error_show" id="edit_error_semester" ></span>
</div>
Batch: *&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select style="height:25px;    -moz-border-radius: 3px;
            -webkit-border-radius: 3px;
            -khtml-border-radius: 3px;
            border-radius: 3px;" name="edit_batch" id="edit_batch" >
        <option value="year">Select year</option>
        <option value="2010">2010</option>
        <option value="2011">2011</option>
        <option value="2012">2012</option>
        <option value="2013">2013</option>
        <option value="2014">2014</option>
        <option value="2015">2015</option>
        <option value="2016">2016</option>
        <option value="2017">2017</option>
        <option value="2018">2018</option>
        <option value="2019">2019</option>
        <option value="2020">2020</option>
        </select>
        <span class="error_show" id="edit_error_batch" ></span>
</div>
</div>
<div class="row2" style="">
	<div class="hello" style=" width:100%;">
    <div class="first" >Gender: *</div>
    <div class="second" style="margin-top:5px; width:250px;">
<input  type="radio" name="sex" id="Male" value="Male"/>Male&nbsp;&nbsp;&nbsp;<input type="radio" id="Female" name="sex" value="Female"  />
Female
</div>
Date of Birth: * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text"
id="edit_dob"  name="edit_dob"  style="height:26px; margin-top:-2px; width:110px; border:1px #ABB0F8 solid; border-radius:4px;" />
<span class="error_show" id="edit_error_dob" ></span>
</div>
</div>
<div class="row1" style="">
	<div class="hello" style=" width:100%;">
    <div class="first" >Country: *</div>
    <div class="second" style="margin-top:1px; width:250px;">
   <select name="edit_your_country" id="edit_your_country" style="height:25px;    -moz-border-radius: 3px;
    -webkit-border-radius: 3px;
    -khtml-border-radius: 3px;
    border-radius: 3px;">
                <option value="country">Country...</option>                
                <option value="Nepal">Nepal</option>
                 <option value="Other">Other</option>
                </select><span class="error_show" id="edit_error_country" ></span>
</div>
District: *&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"
id="edit_district"  name="edit_district" placeholder="EG: Jhapa" style="height:26px; margin-top:-2px; width:110px; border:1px #ABB0F8 solid; border-radius:4px;" /> <span class="error_show" id="edit_error_district" ></span>
</div>
</div>
<div class="row2" style="">
	<div class="hello" style=" width:100%;">
    <div class="first" >City / Village: *</div>
    <div class="second" style="margin-top:-3px; width:250px;">
    <input type="text"  name="edit_place" id="edit_place"  style="height:26px;   width:110px; border:1px #ABB0F8 solid; 
    border-radius:4px;" /> <span class="error_show" id="edit_error_place" ></span>       
</div>
 Mobile Number: *&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='edit_phone' 
id='edit_phone' maxlength="80" placeholder="Member's Phone No." style="height:26px; margin-top:-4px;  width:150px; border:1px #ABB0F8 solid; border-radius:4px;"/><span class="error_show" id="edit_error_phone" ></span>
</div>
</div>
<div class="row1" style="">
	<div class="hello" style=" width:100%;">
    <div class="first" >Email Address: *</div>
    <div class="second" style="margin-top:-4px; width:500px;">
            <input type='text' name='edit_email' id='edit_email'  maxlength="80" placeholder="Member's Email ID" style="height:26px; 
            width:250px; border:1px #ABB0F8 solid; border-radius:4px;"/><span class="error_show" id="edit_error_email" ></span></div></div></div>
<div class="row2" style="">
	<div class="hello" style=" width:100%;">
    <div class="first" >Change Profile Photo:</div>
    <div class="second" style="margin-top:5px; width:250px;">
    <input type="file" name="edit_fileField" id="edit_fileField" />     
</div>
</div>
</div>
<div class="row1" style="border-radius: 0 0 5px 5px; height:60px;"><div class="hlw"><div class="first"></div><div class="second"><input type="submit"  name="edit_m_update" value="Update" onclick="return EditvalidateForm();"  style="height:35px; width:90px; border:1px #666666 solid; background:#F2F2F2; border-radius:5px;" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></div></div>
</form> <!---Form design for edit member detalis-->
</div>
</div><!--End of bs_remove_div from here-->

<script>
function void_search()
{
	$('#show_search_result').slideUp(200); // Hide search box after select and a agent		
}
$(document).ready(function() {
$("#srch_content").keyup(function()
	{
		$('#show_search_result').slideDown(600);	
		if(document.forms["e_form"]["choose_for_what"].value == "book")
		{
		var user_input_data = $("#srch_content").val();
		$.ajax({
			type:"POST",
			url:"book_details_searching_for_edit.php",
			data:{Usersrh:user_input_data},
			success: function(result)
			{
					
				$("#show_search_result").html(result);
			}
			
			
		});
	}  // Search book and show
else if(document.forms["e_form"]["choose_for_what"].value == "member")
		{
			
		var user_input_data = $("#srch_content").val();
		$.ajax({
			type:"POST",
			url:"member_details_searching_for_edit.php",
			data:{Usersrh:user_input_data},
			success: function(result)
			{
					
				$("#show_search_result").html(result);
			}
			
			
		});
	}	
			
	
	});
    
});   // Search member and show
function book_edit_Details(b_id,b_name,b_au,b_r_q,b_avia,b_lang,b_price,b_edi,b_r_time,b_isbn)
	{
		$('#show_search_result').slideUp(800);
		$('#book_edit').slideDown(1000);
		$('#edit_mem_details').slideUp(1000);
		document.getElementById('edit_book_id').value = b_id;
 		document.getElementById('book_edit_id').innerHTML = b_id;
		document.getElementById('book_edit_name').value = b_name;
		document.getElementById('book_edit_price').value = b_price;
		document.getElementById('book_edit_author').value = b_au;
		document.getElementById('book_edit_isbn').value = b_isbn;
		document.getElementById('book_edit_lang').value = b_lang;
		document.getElementById('book_edit_edition').value = b_edi;
		
}  // Retrive and show book last details for edit and save
function mem_edit_Detail_show(m_id,m_f_n,m_m_n,m_l_n,facult,m_pro,m_sem,batch,m_gen,m_dob,m_country,m_district,m_city,m_phone,m_email,m_img_path)
{	   $('#show_search_result').slideUp(800);
		$('#book_edit').slideUp(1000);
		$('#edit_mem_details').slideDown(1000);
		document.getElementById('edit_member_unique_id').value = m_id;
		document.getElementById('edit_mem_id').innerHTML = m_id;
		document.getElementById('edit_fname').value = m_f_n;
		document.getElementById('edit_mname').value = m_m_n;
		document.getElementById('edit_lname').value = m_l_n;
		document.getElementById('edit_mem_faculty').value = facult;
		document.getElementById('edit_mem_program').value = m_pro;
		document.getElementById('edit_mem_semester').value = m_sem;
		document.getElementById('edit_batch').value = batch;
		document.getElementById(m_gen).checked = true;
		document.getElementById('edit_dob').value = m_dob;
		document.getElementById('edit_your_country').value = m_country;
		document.getElementById('edit_district').value = m_district;
		document.getElementById('edit_place').value = m_city;
		document.getElementById('edit_phone').value = m_phone;
		document.getElementById('edit_email').value = m_email;
	
}  // Retrive and show user last details in fields
function EditvalidateForm() {
    if(document.forms["edit_mem_details"]["edit_fname"].value == "" || document.forms["edit_mem_details"]["edit_fname"].value == null) 	{
        alert("You can't leave first name field!!!\n\n");
		edit_fname.focus()
        return false;
    }
		if(document.forms["edit_mem_details"]["edit_lname"].value == "" || document.forms["edit_mem_details"]["edit_lname"].value == null) 
	{
		alert("You can't leave last name field!!!\n\n");
		edit_lname.focus()
        return false;
	}
	if(document.forms["edit_mem_details"]["edit_mem_faculty"].value == "faculty" ) 
	{
		document.getElementById('edit_error_faculty').innerHTML=" required *";
		edit_mem_faculty.focus();
        return false;
	}
	if(document.forms["edit_mem_details"]["edit_mem_program"].value == "program" ) 
	{
		document.getElementById('edit_error_program').innerHTML=" required *";
		edit_mem_program.focus();
        return false;
	}
	if(document.forms["edit_mem_details"]["edit_mem_semester"].value == "semester" ) 
	{
		document.getElementById('edit_error_semester').innerHTML=" required *";
		edit_mem_semester.focus();
        return false;
	}
	if(document.forms["edit_mem_details"]["edit_batch"].value == "year" ) 
	{
		document.getElementById('edit_error_batch').innerHTML=" Select member's batch *";
		edit_batch.focus();
        return false;
	}
	if(document.forms["edit_mem_details"]["edit_dob"].value == "" ) 
	{
		document.getElementById('edit_error_dob').innerHTML=" required *";
		edit_dob.focus();
        return false;
	}
	if(document.forms["edit_mem_details"]["edit_your_country"].value == "country" )
	{
		document.getElementById('edit_error_country').innerHTML=" required *";
		edit_your_country.focus();
        return false;
	}
	
	if(document.forms["edit_mem_details"]["edit_district"].value == "" || document.forms["edit_mem_details"]["edit_district"].value == null)
	{
		document.getElementById('edit_error_district').innerHTML=" required *";
		edit_district.focus();
        return false;
	}
	if(document.forms["edit_mem_details"]["edit_place"].value == "" || document.forms["edit_mem_details"]["edit_place"].value == null)
	{
		document.getElementById('edit_error_place').innerHTML=" required *";
		edit_place.focus();
        return false;
	}
		if(document.forms["edit_mem_details"]["edit_phone"].value == "")
	{
		document.getElementById('edit_error_phone').innerHTML=" required *";
		edit_phone.focus();
        return false;
	}
		if(document.forms["edit_mem_details"]["edit_email"].value == "" || document.forms["edit_mem_details"]["edit_email"].value == null)
	{
		document.getElementById('edit_error_email').innerHTML=" required *";
		edit_email.focus();
        return false;
	}

		 if(document.forms["edit_mem_details"]["edit_phone"].value.match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)) 
        {  
     		  
        }  
      else  
        {  
        document.getElementById('edit_error_phone').innerHTML="  Invalid"; 
		return false;  
        } 
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(edit_mem_details.edit_email.value))  
 		 {  
   			  return true;
 		 }
		 else{  
   			 document.getElementById('edit_error_email').innerHTML="  Invalid";
			 edit_email.focus();
  			  return false;  
		}  

}  // Edit member validation code runs here
function validateEditBookForm() {
if(document.forms["book_edit"]["book_edit_name"].value == "" || document.forms["book_edit"]["book_edit_name"].value == null) 
   {
        document.getElementById('edit_error_name').innerHTML=" required *";
		book_edit_name.focus()
        return false;
    }
if(document.forms["book_edit"]["book_edit_author"].value == "" || document.forms["book_edit"]["book_edit_author"].value == null) 
   {
       document.getElementById('edit_error_author').innerHTML=" required *";
		book_edit_author.focus()
        return false;
    }
if(document.forms["book_edit"]["book_edit_lang"].value == "language" ) 
	{
		document.getElementById('edit_error_language').innerHTML=" required *";
		book_edit_lang.focus()
        return false;
	}
if(document.forms["book_edit"]["book_edit_price"].value == ""  || document.forms["book_edit"]["book_edit_price"].value == null ) 
	{
		document.getElementById('edit_error_price').innerHTML=" required *";
		book_edit_price.focus()
        return false;
	}

}  // Edit book validation code runs here
</script>
<?PHP
// PHP for update book  details in database
include 'Connections/connect_to_db.php';
if(isset($_POST['book_edit_update']))
{
$book_id = $book_name = $author_name = $booK_language = $book_price = $book_isbn =$book_edition= "";
if(isset($_POST['edit_book_id'])){$book_id = $_POST["edit_book_id"];}
$book_name = $_POST["book_edit_name"];
$author_name = $_POST["book_edit_author"];
$booK_language= preg_replace('#[^_A-Za-z0-9]#i', '', $_POST['book_edit_lang']);
$book_price = preg_replace('#[^0-9]#i', '', $_POST['book_edit_price']);
$book_isbn =  preg_replace('#[^_A-Za-z0-9]#i', '', $_POST['book_edit_isbn']);
$book_edition = $_POST['book_edit_edition'];

$insert_books = mysqli_query($connect_db,"UPDATE book_entry SET book_name = '$book_name' , author_name = '$author_name' , book_language = '$booK_language' , book_price = '$book_price' , book_isbn_number = '$book_isbn', book_edition = '$book_edition' WHERE id = '$book_id'") or die (mysqli_error($connect_db));
}
// PHP for detete book entry from database permanently
if(isset($_POST['delete_book']))
{
$delete_book_id = "";
$delete_book_id = $_POST["edit_book_id"];
mysqli_query($connect_db,"DELETE FROM book_entry WHERE id = '$delete_book_id'");
}
// PHP for update member record in database
if(isset($_POST['edit_m_update']))
{
$id = $fname = $mname = $lname = $mfaculty = $mprogram = $msemester = $gender = $b_m =$b_d = $b_y = $country = $district = $city = $email = $phone = $member_unique_id= $batch = "";
$fname = preg_replace('#[^A-Za-z0-9]#i', '', $_POST["edit_fname"]);
$mname = preg_replace('#[^A-Za-z0-9]#i', '', $_POST["edit_mname"]);
$lname = preg_replace('#[^A-Za-z0-9]#i', '', $_POST["edit_lname"]);
$gender = preg_replace('#[^a-z]#i', '', $_POST['sex']);
$mfaculty = $_POST['edit_mem_faculty'];
$mprogram = $_POST['edit_mem_program'];
$msemester = $_POST['edit_mem_semester'];
$batch = $_POST['edit_batch'];
$combine_dob = preg_replace('#[^0-9-]#i', '', $_POST['edit_dob']);
$country= preg_replace('#[^_A-Za-z0-9]#i', '', $_POST['edit_your_country']);
$district = preg_replace('#[^_A-Za-z0-9]#i', '', $_POST['edit_district']);
$city =  preg_replace('#[^_A-Za-z0-9]#i', '', $_POST['edit_place']);
$email = $_POST['edit_email'];
$email = stripslashes($email); 
$emailCHecker = mysqli_real_escape_string($connect_db,$email);
$emailCHecker = str_replace("`", "", $emailCHecker);
$phone = preg_replace('#[^_A-Za-z0-9]#i', '', $_POST['edit_phone']);
$member_unique_id = $_POST["edit_member_unique_id"];

$select = mysqli_query($connect_db,"SELECT * FROM member_entry WHERE unique_id = '$member_unique_id' LIMIT 1");
$fetch_select = mysqli_fetch_array($select);
$id = $fetch_select['id'];

$update = mysqli_query($connect_db,"UPDATE member_entry SET firstname ='$fname' , middlename = '$mname' , lastname = '$lname' , faculty = '$mfaculty' , program = '$mprogram' , semester = '$msemester' , batch = '$batch' , gender = '$gender' , dob = '$combine_dob' , country = '$country' , district = '$district' , city = '$city' , email= '$email' , phone = '$phone' WHERE unique_id = '$member_unique_id'") or die (mysqli_error($connect_db));
	///Old img delect and new upload
  if ($_FILES['edit_fileField']['tmp_name'] != "") {
	    $newname = "$id.jpg";
	    move_uploaded_file($_FILES['edit_fileField']['tmp_name'], "members_image/$newname");
	}
	
}
?>