<?PHP
include'Connections/connect_to_db.php';
if(isset($_POST['details']) != "")
{
	$mem_id = $_POST['details'];
	$sql = mysqli_query($connect_db,"SELECT * FROM member_entry WHERE unique_id = '$mem_id' LIMIT 1");
	while($get_data = mysqli_fetch_array($sql))
	{
		$get_book_details = $get_data['issue_book'];
		if($get_book_details == "")
		{
		 echo '<div style="padding:20px; color:green;">Member did not take any book</div>';	
		}
		else
		{
			$get_book_details = explode(',',$get_book_details);
			$count_book = count($get_book_details);
			$issue_date = "";
			for($j=0; $j<$count_book; $j++)
			{
				$srch = mysqli_query($connect_db,"SELECT * FROM book_transaction WHERE book_id = '$get_book_details[$j]' AND return_book = 0 ORDER BY id DESC ");
				$fetch_srch_result = mysqli_fetch_array($srch);
				$srch_book = mysqli_query($connect_db,"SELECT * FROM book_entry WHERE id = '$get_book_details[$j]'");
				$fetch_srch_book_result = mysqli_fetch_array($srch_book);
				$book_name = $fetch_srch_book_result['book_name'];
				$issue_date = $fetch_srch_result['issue_time'];
				$book_author_name = $fetch_srch_book_result['author_name'];
				$book_isbn = $fetch_srch_book_result['book_isbn_number'];
				$book_register = $fetch_srch_book_result['book_registration_time'];
				$book_id[$j] = $fetch_srch_book_result['id'];				
				
				$get_setting = mysqli_query($connect_db,"SELECT * FROM setting");
				$fetch_setting = mysqli_fetch_array($get_setting);
				$day_after_fine = $fetch_setting['fine_after_day'];
				$per_day_fine = $fetch_setting['per_day_fine'];
				$color="";
				$tot_day = "";
				$show = "";
				$fine_cost = "";
				
				$fine_query = mysqli_query($connect_db,"SELECT * FROM book_transaction WHERE member_id = '$mem_id' AND book_id = '$book_id[$j]' AND return_book = 0");
				if(mysqli_num_rows($fine_query) > 0)
				{
				$fine_fetch = mysqli_fetch_array($fine_query);
				
				$date2= $fine_fetch['issue_time'];
				$date1 = date("Y-m-d");
				$diff = abs(strtotime($date1) - strtotime($date2));
				$years = floor($diff / (365*60*60*24));
				$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
				$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
				$tot_day = $years*365+$months*30+$days;
				$color = "#949494";
				$show = "";
				$fine_cost = "";
				if($tot_day == 1)
				{
					$show =" day ago";
				}
				else if($tot_day > 1)
				{
                    $show = "days ago";
				}
				if($tot_day > $day_after_fine)
				{
					$fine_cost = "| Rs. ";
					$fine_cost .= ($tot_day - $day_after_fine ) * $per_day_fine ;	
					$color = "#f00";
				}
				if($tot_day == 0)
				{
					$tot_day  = "Recently taken";	
				}
				}
				$result = '<form><div><input type="checkbox" class="messageCheckbox"  value="'.$book_id[$j].'" title="ISBN NO.'.$book_isbn.' , Issue On: '.$issue_date.'"/> '.$book_name.'<span style="color:#444; font-size:10px; font-weight:600;">&nbsp;by&nbsp;'.$book_author_name.'</span><span style="float:right; margin:0; padding-top:6px; color:'.$color.'; font-size:0.7em;">'.$tot_day.' '.$show.'&nbsp;&nbsp;'.$fine_cost.'</span></div></form>';
				echo $result;
			}
		
			
		}
	}
		
}
?>
<script>
var checkedValue;
var mem_id = <?PHP echo $mem_id; ?>;
function tick_submit()
{	
	var fine = document.getElementById('hide_fine').value;
 	 var checkedValue = null; 
	 var inputElements = document.getElementsByClassName('messageCheckbox');
	 for(var i=0; inputElements[i]; ++i){
      if(inputElements[i].checked){
           checkedValue = inputElements[i].value+","+checkedValue;
           }
	     }
		 if(checkedValue == null)
		{
		alert("There is no any book selected for return");
		return false;	
		
		}else{
		   $.ajax({
			   type:"POST",
			   url:"perform_book_tick.php",
			   data:{tickValue:checkedValue , mem:mem_id , fine_cost:fine},
			   success: function(res)
			   {
				 $("#tick_error_show").slideDown(50);
			     setTimeout("location.reload(true);",800);
				
			   }	   
			   });
		}
	return false;	
}
</script>