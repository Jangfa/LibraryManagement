<?PHP
session_start();
include 'Connections/connect_to_db.php';
if(isset($_SESSION['password']))
{
	if($_SESSION['password'] != "")
	{
		$input_password = preg_replace('#[^A-Za-z0-9]#i', '', $_SESSION['password']);
		$sql_query = mysqli_query($connect_db,"SELECT * FROM security WHERE id = 1 AND password = '$input_password'") or die("Could not interact with system");
		$check = mysqli_num_rows($sql_query);
		if($check == 0)
		{
			//Confirm that user not exist not database
			header("location:notes_main.php?msg=your_information_are_not_recorded_in_our_system");
			session_destroy();
			exit;
		}
		else if($check != 1)
		{
			header("location:notes_main.php?msg=Something_went_wrong");
			
		}
	}
}
else{
	header("location:notes_main.php?message=your_session_is_expired");
	}
$show_result ="";
$fetch_notes = mysqli_query($connect_db,"SELECT * FROM notes ORDER BY id DESC LIMIT 10");
if(mysqli_num_rows($fetch_notes) > 0)
{
while($fetch_notes_now = mysqli_fetch_array($fetch_notes))
{
   	$note_title = $fetch_notes_now['Title'];
	$note_body = $fetch_notes_now['note'];
	$note_id = $fetch_notes_now['id'];
	$note_time = strftime("%b %d, %Y", strtotime($fetch_notes_now['note_time']));
	$show_result .= '
	<div style="padding:5px;">
    	<div id="note_tit" onClick="javascript:show('.$note_id.');">
       <div style="padding:12px; font-size:15px; font-weight:bold; color:#FFF;">'.ucfirst($note_title).'</div>
        <div id="note_del">
       <a href="notes_admin.php?deleteid='.$note_id.'"><img src="images/delete.png" height="15" width="15" /></a></div>
       <div style="float:right; margin:-15px 80px 0 0; font-size:13px; color:#DFDFDF;">Recorded On:&nbsp;'.$note_time.'</div>
       </div>
             <div id="'.$note_id.'" class="note_show_style" ><div style="padding:10px;">'.ucfirst($note_body).'</div></div>
             
    </div>';
}
}
else
{
  $show_result .= '<div style="height:30px; color:#F0F; font-weight:bold; padding:10px;">There is no any notes found</div>';	
}
?>
<html>
<head>
<title>Admin</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<style>
#note_tit{height:46px; width:98%; margin:-2px auto; background:#7592F4; border-radius:4px; }
#note_del{width:20px; height:20px; float:right; margin:-30px 10px 0 -2px; display:none}
#note_tit:hover{background:#818CF5; cursor:pointer;}
#note_tit:hover > #note_del{display:block; }
.note_show_style {height:auto; min-height:40px; width:98%; display:none; background:#BACCFC; margin:0 auto; border-radius:0 0 4px 4px; }
</style>
<body>
<?PHP include'header.php'; ?>
<div style="height:auto; width:100%; -webkit-box-shadow: -1px 2px 14px -1px rgba(0,0,0,0.75);-moz-box-shadow: -1px 2px 14px -1px rgba(0,0,0,0.75);box-shadow: -1px 2px 14px -1px rgba(0,0,0,0.75);  background:#E1E1E1; margin-top:6px; border-radius:4px; padding-bottom:10px;">
<div style="height:80px; padding:10px;">
<a href="index.php"><div style="float:left; border-radius:4px; color:#CCC; font-weight:bold; height:18px; width:40px; background:#090; padding:8px; margin-right:20px;">Home</div></a>
<div style="height:auto; width:90%; float:left; margin:0 auto;  border-radius:4px; border:1px solid #F2F2F2; background:#D8D8D8;">
<div style="margin:10px; font-weight:bold; font-size:14px; color:#660000;">Create New Note</div>
<div style="margin-left:10px; float:left;"><input type="text" placeholder=" Notes title" name="title" id="title" style="height:30px; border-radius:4px; border:1px solid #999; "  /></div>
<div style="float:left; height:60px; width:62%;margin:-30px 15px 10px 20px;"><textarea style="height:60px; width:100%; border-radius:4px;" placeholder=" Write your note" id="write_note"></textarea></div>
<div style="float:left; margin-top:-20px; "><input type="button" onClick="return valid();" name="save_note" value="Save Note" style="height:30px; width:auto; border-radius:4px; border:1px solid #999;"/>
<div id="success_show" style="height:20px; padding:4px; width:60px; display:none; margin:0 auto;">
<img src="images/yesIcon.png" height="23" width="30" style="margin-left:15px;" /></div>
</div>
</div>
</div>
<?php 
if (isset($_GET['deleteid'])) {
	echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Do you really want to delect this note ?&nbsp;&nbsp;&nbsp; <a href="notes_admin.php?yesdelete=' . $_GET['deleteid'] . '">Yes</a> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="notes_admin.php">No</a>';
	exit();
}
if (isset($_GET['yesdelete'])) {
	$id_to_delete = $_GET['yesdelete'];
	$del_query = mysqli_query($connect_db,"DELETE FROM notes WHERE id='$id_to_delete' LIMIT 1") or die (mysqli_error($sql));
	echo '<META HTTP-EQUIV=Refresh //CONTENT="0; URL=notes_admin.php">';
}
?>
<div style=" margin:0 auto; padding:10px 0 10px 0; border-radius:4px; width:98%;">


<?PHP echo $show_result; ?>


</div>
</div>
</body>
</html>
<script type="text/javascript" src="js/jquery-1.4.3.min.js" ></script>
<script>
function show(x)
{
	if($('#'+x).is(":hidden"))
	{
		$('#'+x).slideDown(100);
	}
	else
	{
		$('#'+x).slideUp(100);
	}
	
}
function valid()
{
	var title_text = document.getElementById('title').value ;
	var nt_body = document.getElementById('write_note').value;
	if(title_text == "" || title_text == null)
	{
	title.focus();
	return false;
	}	
	else if(title_text.length < 3)
	{
		alert("Title is very short");
		return false;
	}
	else if(nt_body == "" || nt_body == null)
	{
	write_note.focus();
	return false;	
	}
	else if(nt_body.length < 10)
	{
		alert("Note body must have to be at least 10 character");
		return false();	
	}
	else
	{
		document.getElementById('title').value="";
		document.getElementById('write_note').value = "";
		
		$.ajax({
			type:"POST",
			url:"post_notes_on_db.php",
			data:{note_title:title_text , note_body:nt_body},
			success: function()
			{
			$('#success_show').slideDown(500);
		    $('#success_show').slideUp(5);
			setTimeout("location.reload(true);",800);
			}
			});
		
	}

}
</script>