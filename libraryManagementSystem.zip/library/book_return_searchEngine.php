<?PHP
try{
	
	$bdd = new PDO("mysql:host=localhost;dbname=project","root","");
}
catch(Exception $e){

 die("ERROR:".$e -> getMessage());	
}



if(isset($_POST['memberInput']) && $_POST['memberInput'] != "" )
{
	 $req = $bdd ->prepare("SELECT * FROM member_entry WHERE firstname LIKE :firstname OR lastname LIKE :lastname OR email LIKE :email OR phone LIKE :phone OR unique_id LIKE :unique_id LIMIT 5") or die("connection failed");
	 $req->execute(array('firstname' => '%'.$_POST['memberInput'].'%','lastname'=>'%'.$_POST['memberInput'].'%','email'=>'%'.$_POST['memberInput'].'%','phone'=>'%'.$_POST['memberInput'].'%','unique_id'=>'%'.$_POST['memberInput'].'%'));
	 if($req -> rowCount()==0)
	 {
		?> 
       <div class="line" style="text-align:center; width:422px;"><?PHP echo"<br/>No member found !!!"; ?></div>
        <?PHP 
	 }else
		{
		while($data = $req ->fetch())
			{
			$sql = mysqli_connect('localhost','root','') or die("Could not connect to database");
			mysqli_select_db($sql,'project');
			$fine_per_day = 0;
			$days_after_fine = 0;
			$member_fine = 0;
			$line_break = " ;   ";
			$book_name = ""; 
			$old_fine = 0;
			$book_author = "";
			$book_date = "";
			$book_count = 0;
			$id = $data['id']; 
			$mem_u_id = $data['unique_id'];
			$book_issue1 = array();
			$book_issue = $data['issue_book'];
			
			$old = mysqli_query($sql,"SELECT * FROM member_entry WHERE unique_id = '$mem_u_id' LIMIT 1");
				$fetch_old_fine = mysqli_fetch_array($old);
				$old_fine = $fetch_old_fine['member_fine'];
			
			if($book_issue != "")
			{
			$book_issue1 = explode(',',$book_issue);
			$book_count = count($book_issue1);	
			for($i=0; $i<$book_count; $i++)
			{
			$get_setting = mysqli_query($sql,"SELECT * FROM setting");
			$get_fine_data = mysqli_fetch_array($get_setting);
			$fine_per_day = $get_fine_data['per_day_fine'];
			$days_after_fine = $get_fine_data['fine_after_day'];
			$book_d = mysqli_query($sql,"SELECT * FROM book_entry WHERE id = $book_issue1[$i]");
			while($get = mysqli_fetch_array($book_d))
			{
				$book_name[$i] = $get['book_name'];
				$book_author[$i] = $get['author_name'];
				$book_id[$i]  = $get['id'];
				
			}
				
						
			 $fine = mysqli_query($sql,"SELECT * FROM book_transaction WHERE book_id = '$book_id[$i]' AND member_id =
					 '$mem_u_id' AND return_book = 0") or die("Something not matched");
			if($check = mysqli_num_rows($fine) > 0)
			 {
			 while($get_fine = mysqli_fetch_array($fine))
			  {
				$date1 = date("Y-m-d");
			    $date2 = $get_fine['issue_time'];
				$diff = abs(strtotime($date1) - strtotime($date2));
				$years = floor($diff / (365*60*60*24));
				$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
				$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
				$tot_day = $years*365+$months*30+$days;
				if($tot_day - $days_after_fine > 0)
				{
					$member_fine = $member_fine + ($tot_day - $days_after_fine) * $fine_per_day;
				}
			   }
			}
			
			/// Fine process end here
			}
			}
			$path = 'members_image/'.$id.'.jpg';
			$default_male = 'members_image/male.png';
			$default_female = 'members_image/female.png';
	
		/////
			if(file_exists($path))
			{
				$img_get = $path;
			}
			else
			{
				if($data['gender'] == "Male")
				{
				$img_get = $default_male;
				}
				else
				{
				$img_get = $default_female;
				}
			}
		 		?>
              
               <div class="line" style="width:422px;" onclick="javascript:return memDetailsReturn('<?PHP echo $book_count; ?>','<?PHP echo $data['unique_id']; ?>','<?PHP echo ucfirst($data['firstname']); ?>','<?PHP echo ucfirst($data['middlename']); ?>','<?PHP echo ucfirst($data['lastname']); ?>','<?PHP echo $data['email']; ?>','<?PHP echo $data['program'];?>','<?PHP echo $data['semester']; ?>','<?PHP echo $book_count; ?>','<?PHP echo $member_fine; ?>','<?PHP echo $old_fine; ?>')" title="Member ID:<?PHP echo $data['unique_id']; ?>"> <div class="img_style">
             <img src="<?PHP echo $img_get; ?>" height="50" width="50" /></div><div class="search_details" style="width:288px;"><span style="font-size:14px; font-weight:bold;">&nbsp;&nbsp;<?PHP echo ucfirst($data['firstname']); echo ucfirst( $data['middlename']); ?> &nbsp;<?PHP echo  ucfirst($data['lastname']);?></span>&nbsp;&nbsp;
                <span style="color:#666; font-size:12px; "><?PHP echo $data['program']; ?>&nbsp;[&nbsp;
				<?PHP echo $data['semester']; ?>&nbsp;]</span><div id="other_info">&nbsp;&nbsp;&nbsp;Email:&nbsp;<?PHP echo $data['email'];?><br />
&nbsp;&nbsp;&nbsp;Number of book issue:&nbsp;<span id="number_color" title="<?PHP for($j=0; $j<$book_count;$j++){ 
echo $book_name[$j];?>  by  <?PHP echo $book_author[$j]; ?><?PHP echo $line_break;}?> " style="height:20px; color:#CCC; text-align:center; background:#333333; border-radius:6px;">
&nbsp; <?PHP echo $book_count; ?>&nbsp;&nbsp;</span></div></div></div>
                
                <?PHP
		
			} 
	 
		 }	
}
else
{
	?>
<div class="line" style="text-align:center; width:422px;"><?PHP echo"<br/>Enter member's Details !!!"; ?></div>
<?PHP
}
?>