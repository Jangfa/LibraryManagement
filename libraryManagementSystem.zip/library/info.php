<?php
if($_POST)
{
	$output = "";
	$output .= '<div class="show_details" style="margin:6px auto;"><div class="book_info"><div class="book_head">
	Book and Member</div></div><ul class="list_item">'; 
	require_once 'Connections/connect_to_db.php';
    if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') 
	{
        die("Sorry we only accept ajax request");
    } 
	if($_POST["fetch"]==1)
	{
		$tot_book = mysqli_query($connect_db,"SELECT id FROM book_entry");
		$tot_book_count = mysqli_num_rows($tot_book);
		$output .= '<li><a>Total number of book: '.$tot_book_count.'</a></li>';
		
		$avi_book = mysqli_query($connect_db,"SELECT id FROM book_entry WHERE available = 1");
		$avi_book_count = mysqli_num_rows($avi_book);
		$output .= '<li><a>Available number of book: '.$avi_book_count.'</a></li>';
		
		$tot_mem = mysqli_query($connect_db,"SELECT id FROM member_entry");
		$tot_mem_count = mysqli_num_rows($tot_mem);
		$output .= '<li><a>Total number of member: '.$tot_mem_count.'</a></li></ul></div>';
		
		$mem_issue = mysqli_query($connect_db,"SELECT * FROM setting WHERE id = 1");
		$fetch_mem_issue = mysqli_fetch_array($mem_issue);
		$mem_can_issue = $fetch_mem_issue['take_book_at_once'];
		$output .= '<div class="show_details" ><div class="book_info"><div class="book_head">Setting and More</div></div>
					<ul class="list_item"><li><a>Number of book a member can issue: '.$mem_can_issue.'</a></li>';
		
		$mem_can_take = $fetch_mem_issue['fine_after_day'];			
		$output .= '<li><a>Number of days a member can keep a book: '.$mem_can_take.'</a></li>';	
		
		$late_fine = $fetch_mem_issue['per_day_fine'];
		$output .= '<li><a>Late fee per day: '.$late_fine.'</a></li></ul></div>';		
		$tot_fine = mysqli_query($connect_db,"SELECT total_fine_receive FROM fine WHERE id = 1");
		$total_collected_fine = "<span style='font-size:0.8em; color:#FF8040;'>No fine collected yet</span>";
		$fe_fine = mysqli_fetch_array($tot_fine);
		$tot_fine_Ch = $fe_fine['total_fine_receive'];
		if($tot_fine_Ch > 0)
		{
		$total_collected_fine = $tot_fine_Ch;
		}
		
		$output .= '<div class="show_details" style="height:115px;"><div class="book_info"><div class="book_head">
			Fine Collection</div></div><ul class="list_item"><li><a>Total Received fine Rs. '.$total_collected_fine.'</a></li>';
			
		$uncollected_fine = 0;
		$un_coll_fine = mysqli_query($connect_db,"SELECT member_fine FROM member_entry");
		while($fetch_un_coll_fine = mysqli_fetch_array($un_coll_fine))
		{
			$un_collected_fine = $fetch_un_coll_fine['member_fine'];
			if($un_collected_fine > 0)
			{
				$uncollected_fine = $uncollected_fine + $un_collected_fine;	
			}
		}
		$output .= '<li><a>Unreceive fine Rs. '.$uncollected_fine.'</a></li></ul></div>';
		echo $output;
		
		
	}
	else
	{
		header('HTTP/1.1 500 Write something to sent '.$sender.' ');
    	exit();
	}
}
?>



